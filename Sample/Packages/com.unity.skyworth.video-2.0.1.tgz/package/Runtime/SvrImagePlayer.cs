using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

public class SvrImagePlayer : MonoBehaviour
{
    private Renderer VideoScreen;
    private string curImage = "";
    private Coroutine coroutine;
    
    private void Awake()
    {
        Init();
    }
    
    private void Init()
    {
        VideoScreen = gameObject.GetComponent<Renderer>();
    }
    
    public void PreparedPlayImage(string url)
    {
        Debug.LogError("PreparedPlayImage " + url);
        bool local = !url.Contains("http://") && !url.StartsWith("https://");
        if (curImage == url)
        {
            return;
        }
        
        curImage = url;
        if (coroutine != null)
        {
            StopCoroutine(coroutine);
        }
        Debug.LogError("LoadImage ");
        VideoScreen.sharedMaterial.mainTexture = null;
        coroutine = StartCoroutine(LoadImage(url, GetFullPath(url, local), (succeed, key, texture) =>
        {
            if (succeed && key == curImage)
            {
                VideoScreen.sharedMaterial.mainTexture = texture;
            }
            coroutine = null;
        }));
    }
    
    /// <summary>
    /// Set the 2D stereo format for the shader.
    /// </summary>
    public void SetPlayMode2D()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        VideoScreen.sharedMaterial.DisableKeyword("_STEREOMODE_LEFTRIGHT");
        VideoScreen.sharedMaterial.DisableKeyword("_STEREOMODE_TOPBOTTOM");
#endif
    }

    /// <summary>
    /// Set the Side-by-Side stereo format for the shader.
    /// </summary>
    public void SetPlayMode3DLeftRight()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        VideoScreen.sharedMaterial.DisableKeyword("_STEREOMODE_TOPBOTTOM");
        VideoScreen.sharedMaterial.EnableKeyword("_STEREOMODE_LEFTRIGHT");
#endif
    }

    /// <summary>
    /// Set the Over-Under stereo format for the shader.
    /// </summary>
    public void SetPlayMode3DTopBottom()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        VideoScreen.sharedMaterial.DisableKeyword("_STEREOMODE_LEFTRIGHT");
        VideoScreen.sharedMaterial.EnableKeyword("_STEREOMODE_TOPBOTTOM");
#endif
    }
    
    IEnumerator LoadImage(string key, string fullPath, Action<bool, string, Texture2D> loadCompleteCallback)
    {
        Debug.LogError("LoadImage " + fullPath);
        UnityWebRequest request = UnityWebRequestTexture.GetTexture(fullPath);
        yield return request.SendWebRequest();
        Texture2D texture = null;
#if UNITY_2020_1_OR_NEWER
        if (request.result == UnityWebRequest.Result.Success)
#else
        if (request.isDone)
#endif
        {
            Debug.LogError("LoadImage Success");
            texture = DownloadHandlerTexture.GetContent(request);
        }
        else
        {
            Debug.LogError("LoadImage Error " + request.error);
        }
        loadCompleteCallback?.Invoke(texture != null, key, texture);
        request.Dispose();
    }

    string GetFullPath(string path, bool isLocal = true)
    {
        if (isLocal)
        {
            if (!path.Contains("file:///") && !path.Contains("file://"))
            {
                switch (Application.platform)
                {
                    case RuntimePlatform.WindowsEditor:
                    case RuntimePlatform.WindowsPlayer:
                    case RuntimePlatform.WSAPlayerX86:
                    case RuntimePlatform.WSAPlayerX64:
                    case RuntimePlatform.WSAPlayerARM:
                        if (!path.Contains("file:///"))
                        {
                            path = "file:///" + path;
                        }
                        break;
                    case RuntimePlatform.Android:
                    case RuntimePlatform.IPhonePlayer:
                        if (!path.Contains("file://"))
                        {
                            path = "file://" + path;
                        }
                        break;
                }
            }
            path = WWW.UnEscapeURL(path, System.Text.Encoding.GetEncoding("utf-8"));
        }
        else
        {
            if (!path.Contains("http://") && !path.Contains("https://"))
            {
                path = "http://" + path;
            }
        }
        return path;
    }
    
    
}
