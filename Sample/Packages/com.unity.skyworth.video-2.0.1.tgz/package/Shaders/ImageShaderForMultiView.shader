﻿// Upgrade NOTE: replaced 'mul(UNITY_MATRIX_MVP,*)' with 'UnityObjectToClipPos(*)'

Shader "Unlit/ImageShaderForMultiView"
{
	Properties
	{
		_MainTex("Base (RGB)", 2D) = "black" {}
		
		_Color("Main Color", Color) = (1,1,1,1)

		[KeywordEnum(None, TopBottom, LeftRight)] _StereoMode("Stereo Mode", Float) = 0
		[Toggle(STEREO_DEBUG)] _StereoDebug("Stereo Debug Tinting", Float) = 0
		
	}
		SubShader
		{
			Tags { "RenderType" = "Opaque" "IgnoreProjector" = "False" "Queue" = "Geometry" }
			LOD 100
			Lighting Off
			Cull Off

			Pass
			{
				CGPROGRAM
				#pragma vertex vert
				#pragma fragment frag
				#pragma multi_compile_fog
				#pragma multi_compile MONOSCOPIC _STEREOMODE_TOPBOTTOM _STEREOMODE_LEFTRIGHT

				// TODO: Change XX_OFF to __ for Unity 5.0 and above
				// this was just added for Unity 4.x compatibility as __ causes
				// Android and iOS builds to fail the shader
				#pragma multi_compile STEREO_DEBUG_OFF STEREO_DEBUG
			

				#include "UnityCG.cginc"

				struct appdata
				{
					float4 vertex : POSITION;
					float2 uv : TEXCOORD0;
	
					UNITY_VERTEX_INPUT_INSTANCE_ID
				};

				struct v2f
				{
					float4 vertex : SV_POSITION;
					float2 uv : TEXCOORD0;
	#if UNITY_VERSION >= 500
					UNITY_FOG_COORDS(1)
	#endif
	#if STEREO_DEBUG
					float4 tint : COLOR;
	#endif
					UNITY_VERTEX_OUTPUT_STEREO //Insert
				};

				uniform sampler2D _MainTex;
	
				uniform float4 _MainTex_ST;
				uniform fixed4 _Color;
				uniform float3 _cameraPosition;

				// We use this method so that when Unity automatically updates the shader from the old
// mul(UNITY_MATRIX_MVP.. to UnityObjectToClipPos that it only changes in one place.
				float4 XFormObjectToClip(float4 vertex)
				{
#if defined(SHADERLAB_GLSL)
					return gl_ModelViewProjectionMatrix * vertex;
#else
#if (UNITY_VERSION >= 560)
					return UnityObjectToClipPos(vertex);
#else
					return UnityObjectToClipPos(vertex);
#endif
#endif
				}

				bool IsStereoEyeLeft(float3 worldNosePosition, float3 worldCameraRight)
				{
#if defined(FORCEEYE_LEFT)
					return true;
#elif defined(FORCEEYE_RIGHT)
					return false;
#elif  defined(UNITY_STEREO_MULTIVIEW_ENABLED)
					// Unity 5.4 has this new variable
					return unity_StereoEyeIndices[unity_StereoEyeIndex].x == 0;//(unity_StereoEyeIndex == 0);
#elif defined (UNITY_DECLARE_MULTIVIEW)
					// OVR_multiview extension
					return (UNITY_VIEWID == 0);
#else

					//#if (UNITY_VERSION > 540) && defined(GOOGLEVR) && !defined(SHADERLAB_GLSL)
						// Daydream support uses the skew component of the projection matrix
						// (But unity_CameraProjection doesn't seem to be declared when using GLSL)
						// NOTE: we've had to remove this minor optimisationg as it was causing too many isues.  
						//       eg. Unity 5.4.1 in GLSL mode complained UNITY_VERSION and unity_CameraProjection aren't defined
						//return (unity_CameraProjection[0][2] > 0.0);
					//#else
						// worldNosePosition is the camera positon passed in from Unity via script
						// We need to determine whether _WorldSpaceCameraPos (Unity shader variable) is to the left or to the right of _cameraPosition
					float dRight = distance(worldNosePosition + worldCameraRight, _WorldSpaceCameraPos);
					float dLeft = distance(worldNosePosition - worldCameraRight, _WorldSpaceCameraPos);
					return (dRight > dLeft);
					//#endif

#endif
				}

#if defined(_STEREOMODE_TOPBOTTOM) || defined(_STEREOMODE_LEFTRIGHT)
				float4 GetStereoScaleOffset(bool isLeftEye, bool isYFlipped)
				{
					float2 scale = float2(1.0, 1.0);
					float2 offset = float2(0.0, 0.0);

					// Top-Bottom
#if defined(_STEREOMODE_TOPBOTTOM)

					scale.y = 0.5;
					offset.y = 0.0;

					if (!isLeftEye)
					{
						offset.y = 0.5;
					}

#if !defined(SHADERLAB_GLSL) 
#if !defined(UNITY_UV_STARTS_AT_TOP)	// UNITY_UV_STARTS_AT_TOP is for directx
					if (!isYFlipped)
					{
						// Currently this only runs for Android and Windows using DirectShow
						offset.y = 0.5 - offset.y;
					}
#endif
#endif

					// Left-Right 
#elif defined(_STEREOMODE_LEFTRIGHT)

					scale.x = 0.5;
					offset.x = 0.0;
					if (isLeftEye)
					{
						offset.x = 0.5;
					}

#endif

					return float4(scale, offset);
				}
#endif

#if defined(STEREO_DEBUG)
				float4 GetStereoDebugTint(bool isLeftEye)
				{
					float4 tint = float4(1.0, 1.0, 1.0, 1.0);

#if defined(_STEREOMODE_TOPBOTTOM) || defined(_STEREOMODE_LEFTRIGHT) || defined(STEREO_CUSTOM_UV)
					float4 leftEyeColor = float4(0.0, 1.0, 0.0, 1.0);		// green
					float4 rightEyeColor = float4(1.0, 0.0, 0.0, 1.0);		// red

					if (isLeftEye)
					{
						tint = leftEyeColor;
					}
					else
					{
						tint = rightEyeColor;
					}
#endif

#if defined(UNITY_UV_STARTS_AT_TOP)
					tint.b = 0.5;
#endif

					return tint;
				}
#endif

				v2f vert(appdata v)
				{
					v2f o;
					UNITY_SETUP_INSTANCE_ID(v); //Insert
					UNITY_INITIALIZE_OUTPUT(v2f, o); //Insert
					UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o); //Insert
					o.vertex = XFormObjectToClip(v.vertex);
					o.uv.xy = TRANSFORM_TEX(v.uv, _MainTex);

	#if STEREO_DEBUG
					o.tint = GetStereoDebugTint(IsStereoEyeLeft(_cameraPosition, UNITY_MATRIX_V[0].xyz));
	#endif

	#if UNITY_VERSION >= 500
					UNITY_TRANSFER_FOG(o, o.vertex);
	#endif

					return o;
				}

				fixed4 frag(v2f i) : SV_Target
				{
					UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
	#if _STEREOMODE_TOPBOTTOM | _STEREOMODE_LEFTRIGHT
	#ifdef UNITY_STEREO_MULTIVIEW_ENABLED
				float4 scaleOffset = GetStereoScaleOffset(unity_StereoEyeIndices[unity_StereoEyeIndex].x == 0, _MainTex_ST.y < 0.0);
				i.uv.xy *= scaleOffset.xy;
				i.uv.xy += scaleOffset.zw;
	#endif
	#endif
				i.uv.xy = float2(1 - i.uv.x, i.uv.y);
				fixed4 col = tex2D(_MainTex, i.uv.xy);
				col *= _Color*1.25;
	#if STEREO_DEBUG
					col *= i.tint;
	#endif				

	#if UNITY_VERSION >= 500
					UNITY_APPLY_FOG(i.fogCoord, col);
	#endif

					return fixed4(col.rgb, 1.0);
				}
				ENDCG
			}
		}
}
