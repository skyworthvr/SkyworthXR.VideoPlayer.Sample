﻿// Copyright 2020 Skyworth VR. All rights reserved.
Shader "Svr/SvrVideoUnlitShaderForCube" {
	Properties{
		_Gamma("Video gamma", Range(0.01,3.0)) = 1.0
		_MainTex("Base (RGB)", 2D) = "white" {}
		_Color("Main Color", Color) = (1,1,1,1)
		[Toggle(STEREOMODE)] _StereoMode("Stereo mode", Float) = 0
		[Toggle(FLIP_X)] _FlipX("Flip X", Int) = 1
		[Toggle(USE_STEREO)] _UseStereo("Use stereo", Int) = 1
		[HideInInspector] _SrcBlend ("__src", Float) = 1.0
		[HideInInspector] _DstBlend ("__dst", Float) = 0.0
		[HideInInspector] _ZWrite ("__zw", Float) = 1.0
	}

	SubShader {
		Tags { "RenderType" = "Opaque" "Queue" = "Background" "IgnoreProjector" = "True"  }
		LOD 100
		Lighting Off
		Cull Off
		// These values are toggled from code.
		ZWrite [_ZWrite]
		Blend [_SrcBlend] [_DstBlend]
		Pass {
			GLSLPROGRAM
			//#version 310 es
			#include "UnityCG.glslinc"
			#include "UnityStereoSupport.glslinc"
			#include "UnityStereoExtensions.glslinc"
			#include "CubeMap.glslinc"
			#define SHADERLAB_GLSL
			#pragma only_renderers gles gles3
			#extension GL_OES_EGL_image_external       : enable
			#extension GL_OES_EGL_image_external_essl3 : enable
			#extension GL_OVR_multiview                : enable
			// Force high precision on our shader to prevent rounding errors from creeping up
			precision highp float;
			#pragma multi_compile ___ FLIP_X
			#pragma multi_compile ___ USE_STEREO
			#pragma multi_compile ___ STEREOMODE
			#ifdef VERTEX
				varying float UnityEyeIndex;
				varying vec2 uvs;
				varying vec3 vs_TEXCOORD0;
				uniform vec4 _MainTex_ST;
				// uniform mat4 video_matrix;
				uniform int Svr_StereoEyeIndex;
				uniform int _UseStereo;
				uniform int _FlipX;

				vec2 transformTex(vec2 texCoord, vec4 texST) {
					return (texCoord.xy * texST.xy + texST.zw);
				}

				void main() {
					int eyeindex = SetupStereoEyeIndex();
					UnityEyeIndex = float(eyeindex);
					#if defined (STEREO_MULTIVIEW_ON)
						gl_Position = GetStereoMatrixVP(eyeindex) * unity_ObjectToWorld * gl_Vertex;
					#else
						gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
					#endif
					vec4 untransformedUV = 	gl_MultiTexCoord0;

					uvs = transformTex(untransformedUV.xy, _MainTex_ST);
					vs_TEXCOORD0.xyz = gl_Vertex.xyz;
				}
			#endif

			#ifdef FRAGMENT
				varying float UnityEyeIndex;
				varying vec2 uvs;
				varying vec3 vs_TEXCOORD0;
				uniform samplerExternalOES _MainTex;
				// uniform sampler2D _MainTex;
				uniform vec4 _Color;

				void main() {
					vec2 texcoord;
					#ifdef STEREOMODE
						texcoord = EquiAngularCubemapStero(vs_TEXCOORD0, vec2(0.0),UnityEyeIndex);
					#else
						texcoord = EquiAngularCubemap(vs_TEXCOORD0, vec2(0.001));
					#endif
					#if __VERSION__ >= 300
						gl_FragColor = texture(_MainTex, texcoord.xy) * _Color;
					#else
						gl_FragColor = texture2D(_MainTex, texcoord.xy) * _Color;
					#endif
				}
			#endif
			ENDGLSL
		}
	}
	SubShader
	{
		Tags { "RenderType" = "Opaque" "Queue" = "Background" "IgnoreProjector" = "True"  }
		LOD 100
		Lighting Off
		Cull Off
		// These values are toggled from code.
		ZWrite [_ZWrite]
		Blend [_SrcBlend] [_DstBlend]
		Pass
		{
			CGPROGRAM
			#pragma vertex vert
			#pragma fragment frag
			#pragma only_renderers metal d3d11 glcore
			#pragma multi_compile ___ FLIP_X
			#include "UnityCG.cginc"

			struct appdata {
				float4 vertex : POSITION;
				float2 uv : TEXCOORD0;
			};

			struct v2f {
				float4 vertex : SV_POSITION;
				float2 uv : TEXCOORD0;
			};

			uniform sampler2D _MainTex;
			uniform float4 _MainTex_ST;
			uniform fixed4 _Color;

			v2f vert (appdata appData) {
				v2f output;

				output.vertex = UnityObjectToClipPos(appData.vertex);
				#ifdef FLIP_X
					appData.uv.x = 1.0 - appData.uv.x;
				#endif
				output.uv.xy = TRANSFORM_TEX(appData.uv, _MainTex);
				return output;
			}
			fixed4 frag (v2f input) : SV_Target
			{
				fixed4 col = tex2D(_MainTex, input.uv.xy);
				col *= _Color;
				return fixed4(col.rgb, 1.0);
			}
			ENDCG
		}
	}
}
